def selectionsort(ar):

    """

    Implement the Selection Sort algorithm for sorting a list of elements in ascending order.


    :param ar: A list of elements to be sorted.

    :return: The sorted list.

    """

    for i in range(len(ar) - 1):

        mn_idx = i

        for idx in range(i + 1, len(ar)):

            if ar[idx] < ar[mn_idx]:

                mn_idx = idx

        ar[i], ar[mn_idx] = ar[mn_idx], ar[i]

    return ar


ar = [23, 45, 67, 44, 34, 32, 12]

sorted_ar = selectionsort(ar)

print("Sorted array:", sorted_ar)