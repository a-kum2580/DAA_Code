def insertion_sort(a):

    """

    Implement the Insertion Sort algorithm for sorting a list of elements in ascending order.


    :param a: A list of elements to be sorted.

    :return: The sorted list.

    """

    for i in range(1, len(a)):

        key = a[i]

        j = i - 1

        while j >= 0 and key < a[j]:

            a[j + 1] = a[j]

            j -= 1

        a[j + 1] = key

    return a


a = [12, 13, 11, 5, 7]

sorted_a = insertion_sort(a)

print('Sorted array is:', sorted_a)